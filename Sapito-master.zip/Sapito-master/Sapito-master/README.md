# `💫 𝑆APITO - 𝐵OT 💫`

### `—◉ 👑 DUDAS SOBRE EL BOT?, CONTACTAME 👑`
<a href="http://wa.me/595983186566?text=Hola bro vengo de github" target="blank"><img src="https://img.shields.io/badge/Sapito-25D366?style=for-the-badge&logo=WhatsApp&logoColor=purple" /></a>
> NO BOT.     

# `Sigueme en TikTok`

@Psto36_5

# `Me das una estrella 🌟 porfis 😽`

```bash
Ola Bro 👋

```

### `—◉ ⚙️ AJUSTES ⚙️`

### `—◉ 👾 ACTIVAR EN TERMUX 👾`
# `ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:`
```bash

> cd
> termux-setup-storage
> apt update 
> apt upgrade 
> apt install yarn 
> apt install git -y
> apt install nodejs -y
> apt install ffmpeg -y
> apt install imagemagick -y
> git clone https://github.com/sapitoBot2/Sapito
> cd Sapito
> yarn install
> npm install
> npm update
> npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE ✔️`
# `ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:`
```bash

> cd 
> cd Sapito
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR 👽`
# `ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:`
```bash

> cd 
> cd Sapito
> rm -rf session.data.json
> npm start
```

Para saber mas sobre el Bot.     

https://youtu.be/o-YBDTqX_ZU



## `EDITOR Y PORPIETARIO DEL BOT` 
[![Sapito}/) 

`Simple - Bot By Sapito`
